<div class="large-4 columns">
    <a href="<?php echo $ribbon_link; ?>" target="_blank">
        <div class="corner-ribbon top-right sticky blue shadow"><?php echo $ribbon_title; ?></div>
    </a>
</div>